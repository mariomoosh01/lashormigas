# Control de inventarios por Gibrán Majalca
## Lista de sistemas:
Sistema de inventario
Sistema de requisiciones
Control de salidas y entradas.